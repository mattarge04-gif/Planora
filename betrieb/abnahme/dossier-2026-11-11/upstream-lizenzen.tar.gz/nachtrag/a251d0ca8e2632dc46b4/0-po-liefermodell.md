# Planora: Lizenz- und Liefermodell (PO-Entscheid 2026-11-11)

- Planora (`planora-app`) ist proprietaer; alle Rechte liegen beim Anbieter.
- Der Kunde erhaelt ein nicht-exklusives, nicht uebertragbares Nutzungsrecht fuer seine Instanz waehrend der Vertragsdauer.
- Lieferung und Betrieb erfolgen als signierte Images; Quellcode wird nicht geliefert.
- Betriebsmodell: Der Anbieter stellt Server (CH-VM) und Domain und betreibt die Instanz; der Kunde braucht keine eigene IT.
- Drittkomponenten in den Images stehen unter ihren eigenen Lizenzen gemaess diesem Dossier (SBOMs, Lizenzarchive, upstream-nachweis.json).

[?] Offen (juristisch): schriftliche Rechtekette Entwickler -> Firma und der Vertragstext mit dem Kunden.
